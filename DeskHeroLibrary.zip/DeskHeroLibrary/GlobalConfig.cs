﻿using Dapper;
using DeskHeroLibrary.DataAccess;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace DeskHeroLibrary
{
    public static class GlobalConfig
    {
        public static IDataConnection Connection { get; private set; }


        public static void InitializeConnections()
        {

            SQLConnector sql = new SQLConnector();
            Connection = sql;



        }
        public static string CnnString(string name)
        {
            var conn = ConfigurationManager.ConnectionStrings[name];

            if (conn == null)
            {
                throw new InvalidOperationException($"Connection string '{name}' was not found in the application configuration.");
            }

            return conn.ConnectionString;
        }
    }
}
