﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeskHeroLibrary.Models
{
    public class TicketModel
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public int PriorityId { get; set; }
        public PriorityModel Priority { get; set; } // Full object for display/binding

        public int ProficiencyId { get; set; }
        public ProficiencyModel Proficiency { get; set; }

        public int TeamMemberAssignedId { get; set; }
        public TeamMemberModel TeamMemberAssigned { get; set; }

        public int EstimatedTimeToComplete { get; set; }
        public string Description { get; set; }

        public bool CompletionFlag { get; set; }
        public override string ToString()
        {
            // Format the string to display key attributes from the related models
            return $"Ticket: {Name}, Assigned To: {TeamMemberAssigned?.Name}, " +
                   $"Estimated Time: {EstimatedTimeToComplete} hours";
        }
    }
}