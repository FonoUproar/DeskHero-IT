﻿using Dapper;
using DeskHeroLibrary.DataAccess;
using DeskHeroLibrary.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DeskHeroLibrary
{
    public class SQLConnector : IDataConnection
    {
        private const string db = "DeskHeroIt";
        TeamMemberModel IDataConnection.CreateTeamMember(TeamMemberModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {

                var p = new DynamicParameters();
                p.Add("@Name", model.Name);
                p.Add("@ProficiencyId", model.ProficiencyId);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);

                connection.Execute("dbo.spTeamMember_Insert", p, commandType: CommandType.StoredProcedure);

                model.Id = p.Get<int>("id");

                return model;

            }
        }

        TicketModel IDataConnection.CreateTicket(TicketModel model)
        {

            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {
                var p = new DynamicParameters();
                p.Add("@Name", model.Name);
                p.Add("@PriorityId", model.PriorityId); 
                p.Add("@ProficiencyId", model.ProficiencyId);
                p.Add("@TeamMemberAssignedId", model.TeamMemberAssignedId);
                p.Add("@EstimatedTimeToComplete", model.EstimatedTimeToComplete);
                p.Add("@Description", model.Description);
                p.Add("@CompletionFlag", model.CompletionFlag);
                p.Add("@id", 0, dbType: DbType.Int32, direction: ParameterDirection.Output);

                connection.Execute("dbo.spTickets_Insert", p, commandType: CommandType.StoredProcedure);

                model.Id = p.Get<int>("id");

                return model;
            }
        }


        void IDataConnection.DeleteTeamMember(TeamMemberModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {
                {
                    var p = new DynamicParameters();
                    p.Add("@Id", model.Id);

                    connection.Execute("spTeamMembers_DeleteSelected", p, commandType: CommandType.StoredProcedure);
                }
            }
        }

        void IDataConnection.DeleteTicket(TicketModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {
                {
                    var p = new DynamicParameters();
                    p.Add("@Id", model.Id);

                    connection.Execute("spTickets_DeleteSelected", p, commandType: CommandType.StoredProcedure);
                }
            }
        }

        List<ProficiencyModel> IDataConnection.Proficiency_GetAll()
        {
            List<ProficiencyModel> output;
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {
                output = connection.Query<ProficiencyModel>("dbo.spProficiencies_GetAll").ToList();
            }
            return output;
        }
        List<PriorityModel> IDataConnection.Priority_GetAll()
        {
            List<PriorityModel> output;
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {
                output = connection.Query<PriorityModel>("dbo.spPriorities_GetAll").ToList();
            }
            return output;
        }

        List<TeamMemberModel> IDataConnection.TeamMember_GetAll()
        {
            List<TeamMemberModel> output;
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {
                output = connection.Query<TeamMemberModel>("dbo.spTeamMembers_GetAll").ToList();
            }
            return output;
        }

        List<TicketModel> IDataConnection.Ticket_GetAll()
        {
            // load flat tickets
            List<TicketModel> tickets;
            using (var conn = new SqlConnection(GlobalConfig.CnnString(db)))
            {
                tickets = conn
                  .Query<TicketModel>("dbo.spTickets_GetAll", commandType: CommandType.StoredProcedure)
                  .ToList();
            }

            // load team members once
            var teamMembers = GlobalConfig.Connection.TeamMember_GetAll();

            // assign nested objects
            foreach (var t in tickets)
            {
                t.TeamMemberAssigned = teamMembers
                  .FirstOrDefault(m => m.Id == t.TeamMemberAssignedId);
            }

            return tickets;
        }
        void IDataConnection.UpdateTicket(TicketModel model)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(GlobalConfig.CnnString(db)))
            {
                var p = new DynamicParameters();
                p.Add("@Id", model.Id);
                p.Add("@Name", model.Name);
                p.Add("@PriorityId", model.PriorityId);
                p.Add("@ProficiencyId", model.ProficiencyId);
                p.Add("@TeamMemberAssignedId", model.TeamMemberAssignedId);
                p.Add("@EstimatedTimeToComplete", model.EstimatedTimeToComplete);
                p.Add("@Description", model.Description);
                p.Add("@CompletionFlag", model.CompletionFlag);

                connection.Execute(
                    "dbo.spTickets_Update",
                    p,
                    commandType: CommandType.StoredProcedure
                );
            }
        }
    }
}
