﻿using DeskHeroLibrary;
using DeskHeroLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT488_DeskHeroIT
{
    public partial class NewTicketForm : Form
    {
        private static NewTicketForm instance;
        private readonly DashboardForm dashboardForm;

        private NewTicketForm(DashboardForm DashboardForm)
        {
            InitializeComponent();
            dashboardForm = DashboardForm;

            // Populate dropdowns
            ticketDifficultyComboBox.DataSource = GlobalConfig.Connection.Proficiency_GetAll();
            ticketDifficultyComboBox.DisplayMember = "Name";
            ticketDifficultyComboBox.ValueMember = "Id";

            ticketPriorityComboBox.DataSource = GlobalConfig.Connection.Priority_GetAll();
            ticketPriorityComboBox.DisplayMember = "Name";
            ticketPriorityComboBox.ValueMember = "Id";

            assignedTeamMemberComboBox.DataSource = new List<TeamMemberModel>();
            assignedTeamMemberComboBox.DisplayMember = "Name";
            assignedTeamMemberComboBox.ValueMember = "Id";

            // Wire up the SelectionChangeCommitted event
            ticketDifficultyComboBox.SelectionChangeCommitted += TicketDifficultyComboBox_SelectionChangeCommitted;

            ClearFormFields();
        }

        private void TicketDifficultyComboBox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (ticketDifficultyComboBox.SelectedValue is int profId && profId > 0)
            {
                var allMembers = GlobalConfig.Connection.TeamMember_GetAll();

                // Adjust the comparison based on your proficiency ID logic
                var eligible = allMembers.Where(tm => tm.ProficiencyId >= profId).ToList();

                assignedTeamMemberComboBox.DataSource = null;
                assignedTeamMemberComboBox.DataSource = eligible;
                assignedTeamMemberComboBox.DisplayMember = "Name";
                assignedTeamMemberComboBox.ValueMember = "Id";
            }
            else
            {
                assignedTeamMemberComboBox.DataSource = null;
            }
        }

        public static NewTicketForm GetInstance(Form home)
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new NewTicketForm((DashboardForm)home);
            }
            return instance;
        }

        private void NewTicketForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            instance = null;
        }

        protected override void OnShown(EventArgs e)
        {
            base.OnShown(e);
            ClearFormFields();
        }

        private void ClearFormFields()
        {
            ticketNameTextBox.Clear();
            ticketPriorityComboBox.SelectedIndex = -1;
            ticketDifficultyComboBox.SelectedIndex = -1;
            assignedTeamMemberComboBox.DataSource = null;
            estimatedCompletionTimeTextBox.Clear();
            issueDescriptionTextbox.Clear();
        }

        private void createTicketButton_Click(object sender, EventArgs e)
        {
            if (!ValidateTicket()) return;

            var ticket = new TicketModel
            {
                Name = ticketNameTextBox.Text.Trim(),
                EstimatedTimeToComplete = int.Parse(estimatedCompletionTimeTextBox.Text),
                Description = issueDescriptionTextbox.Text.Trim(),
                PriorityId = (int)ticketPriorityComboBox.SelectedValue,
                ProficiencyId = (int)ticketDifficultyComboBox.SelectedValue,
                TeamMemberAssignedId = (int)assignedTeamMemberComboBox.SelectedValue,
                CompletionFlag = false
            };

            GlobalConfig.Connection.CreateTicket(ticket);

            if (dashboardForm != null && !dashboardForm.IsDisposed)
            {
                dashboardForm.ReloadOpenTickets();
                dashboardForm.Show();
            }
            else
            {
                new DashboardForm().Show();
            }

            Close();
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            Close();
            if (dashboardForm != null && !dashboardForm.IsDisposed)
                dashboardForm.Show();
            else
                new DashboardForm().Show();
        }

        private void clearTicketButton_Click(object sender, EventArgs e)
        {
            ClearFormFields();
        }

        private bool ValidateTicket()
        {
            bool output = true;
            bool estimatedCompletionTimeValidValue = int.TryParse(estimatedCompletionTimeTextBox.Text, out int estimateCompletionTime);

            if (string.IsNullOrWhiteSpace(ticketNameTextBox.Text))
            {
                MessageBox.Show("Current entry for ticket name is blank. Please enter a valid ticket name.");
                output = false;
            }
            else if (ticketNameTextBox.Text.Length > 100)
            {
                MessageBox.Show("Current entry for ticket name exceeds 100 characters, please enter a shorter name.");
                output = false;
            }

            if (ticketPriorityComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("No ticket priority selected, please select one of the available options.");
                output = false;
            }

            if (ticketDifficultyComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("No ticket difficulty selected, please select one of the available options.");
                output = false;
            }

            if (assignedTeamMemberComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("No team member is assigned to this ticket, please select one of the available options.");
                output = false;
            }

            if (!estimatedCompletionTimeValidValue)
            {
                MessageBox.Show("Current time estimate is not a valid number. Please enter a valid number. (1 represents 1 hour)");
                output = false;
            }
            else if (estimateCompletionTime < 1)
            {
                MessageBox.Show("Current time estimate is less than 1 hour, please enter a valid number. (1 represents 1 hour)");
                output = false;
            }

            if (issueDescriptionTextbox.Text.Length > 1000)
            {
                MessageBox.Show("Current entry for ticket description exceeds 1000 characters, please enter a shorter description.");
                output = false;
            }

            return output;
        }
    }
}
//    public partial class NewTicketForm : Form
//    {
//        private static NewTicketForm instance;
//        private readonly DashboardForm dashboardForm;

//        private NewTicketForm(DashboardForm DashboardForm)
//        {
//            InitializeComponent();
//            dashboardForm = DashboardForm;

//            // Populate dropdowns
//            ticketDifficultyComboBox.SelectedValueChanged += TicketDifficultyComboBox_SelectedValueChanged;
//            // --- then bind the lookup lists ---
//            ticketDifficultyComboBox.DataSource = GlobalConfig.Connection.Proficiency_GetAll();
//            ticketDifficultyComboBox.DisplayMember = "Name";
//            ticketDifficultyComboBox.ValueMember = "Id";

//            assignedTeamMemberComboBox.DataSource = new List<TeamMemberModel>();
//            assignedTeamMemberComboBox.DisplayMember = "Name";
//            assignedTeamMemberComboBox.ValueMember = "Id";
//            ticketPriorityComboBox.DataSource = GlobalConfig.Connection.Priority_GetAll();
//            ticketPriorityComboBox.DisplayMember = "Name";
//            ticketPriorityComboBox.ValueMember = "Id";
//            ClearFormFields();
//        }
//        private void TicketDifficultyComboBox_SelectedValueChanged(object sender, EventArgs e)
//        {
//            var allMembers = GlobalConfig.Connection.TeamMember_GetAll();
//            Debug.WriteLine($"Members: {allMembers.Count}");
//            if (!(ticketDifficultyComboBox.SelectedValue is int profId) || profId <= 0)
//            {
//                Debug.WriteLine("No valid prof selected");
//                assignedTeamMemberComboBox.DataSource = null;
//                return;
//            }

//            Debug.WriteLine($"Filtering for proficiency >= {profId}");
//            var eligible = allMembers.Where(tm => tm.ProficiencyId >= profId).ToList();

//            Debug.WriteLine($"Eligible count: {eligible.Count}");
//            assignedTeamMemberComboBox.DataSource = null;
//            assignedTeamMemberComboBox.DataSource = eligible;
//            assignedTeamMemberComboBox.DisplayMember = "Name";
//            assignedTeamMemberComboBox.ValueMember = "Id";
//        }


//        public static NewTicketForm GetInstance(Form home)
//        {
//            // Always create a new instance if the old one has been closed
//            if (instance == null || instance.IsDisposed)
//            {
//                instance = new NewTicketForm((DashboardForm)home);
//            }
//            return instance;
//        }

//        private void NewTicketForm_FormClosed(object sender, FormClosedEventArgs e)
//        {
//            // Reset singleton so next GetInstance() makes a fresh form
//            instance = null;
//        }

//        protected override void OnShown(EventArgs e)
//        {
//            base.OnShown(e);
//            // Clear all fields each time the form is shown
//            ClearFormFields();
//        }

//        private void ClearFormFields()
//        {
//            ticketNameTextBox.Clear();
//            ticketPriorityComboBox.SelectedIndex = -1;
//            ticketDifficultyComboBox.SelectedIndex = -1;
//            assignedTeamMemberComboBox.SelectedIndex = -1;
//            estimatedCompletionTimeTextBox.Clear();
//            issueDescriptionTextbox.Clear();
//        }

//        private void createTicketButton_Click(object sender, EventArgs e)
//        {
//            if (!ValidateTicket()) return;

//            var ticket = new TicketModel
//            {
//                Name = ticketNameTextBox.Text.Trim(),
//                EstimatedTimeToComplete = int.Parse(estimatedCompletionTimeTextBox.Text),
//                Description = issueDescriptionTextbox.Text.Trim(),
//                PriorityId = (int)ticketPriorityComboBox.SelectedValue,
//                ProficiencyId = (int)ticketDifficultyComboBox.SelectedValue,
//                TeamMemberAssignedId = (int)assignedTeamMemberComboBox.SelectedValue,
//                CompletionFlag = false
//            };

//            GlobalConfig.Connection.CreateTicket(ticket);

//            // Tell dashboard to refresh and then hide this form
//            if (dashboardForm is DashboardForm dash)
//            {
//                dash.ReloadOpenTickets();
//                dash.Show();
//            }
//            Close(); // triggers FormClosed -> instance = null
//        }


//        private void backButton_Click(object sender, EventArgs e)
//        {
//            Close(); // also resets instance
//            if (dashboardForm != null && !dashboardForm.IsDisposed)
//                dashboardForm.Show();
//            else
//                new DashboardForm().Show();
//        }

//        private void clearTicketButton_Click(object sender, EventArgs e)
//        {
//            ClearFormFields();
//        }


//        private bool ValidateTicket()
//        {
//            bool output = true;
//            bool estimatedCompletionTimeValidValue = Int32.TryParse(estimatedCompletionTimeTextBox.Text, out Int32 estimateCompletionTime);
//            if (ticketNameTextBox.Text == null)
//            {
//                MessageBox.Show("Current entry for ticket name is blank. Plase enter a valid ticket name");
//                output = false;
//            }
//            if (ticketNameTextBox.Text.Length > 100)
//            {
//                MessageBox.Show("Current entry for ticket name exceeds 100 charaters, please enter a shorter name");
//                output = false;
//            }
//            if (ticketPriorityComboBox.Text == null)
//            {
//                MessageBox.Show("No ticket priority selected, please select one of the available options");
//                output = false;
//            }
//            if (ticketDifficultyComboBox.Text == null)
//            {
//                MessageBox.Show("No ticket difficulty selected, please select one of the available options");
//                output = false;
//            }

//            if (assignedTeamMemberComboBox.Text == null)
//            {
//                MessageBox.Show("No team member is assigned to this ticket, please select one of the available options.");
//                output = false;
//            }

//            if (!estimatedCompletionTimeValidValue)
//            {
//                MessageBox.Show("Current time estimate is not a valid number. Please enter a valid number.(1 represents 1 hour)");
//                output = false;
//            }

//            if (estimateCompletionTime < 1)
//            {
//                MessageBox.Show("Current time estimate is negative or less than 1 hour, please enter a valid number.(1 represents 1 hour)");
//                output = false;
//            }

//            if (issueDescriptionTextbox.Text.Length > 1000)
//            {
//                MessageBox.Show("Current entry for ticket description exceeds 1000 charaters, please enter a shorter description");
//                output = false;
//            }
//            return output;
//        }
//        // ... ValidateTicket() stays the same ...
//    }
//}


