﻿using DeskHeroLibrary;
using DeskHeroLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT488_DeskHeroIT
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
            GlobalConfig.InitializeConnections();
            StartPosition = FormStartPosition.CenterScreen;

            // Initialize priority dropdowns
            var priorities = GlobalConfig.Connection.Priority_GetAll();
            openTicketsPriorityComboBox.DataSource = priorities;
            closedTicketsPriorityComboBox.DataSource = priorities;
            openTicketsPriorityComboBox.DisplayMember = closedTicketsPriorityComboBox.DisplayMember = "Name";
            openTicketsPriorityComboBox.ValueMember = closedTicketsPriorityComboBox.ValueMember = "Id";
            openTicketsPriorityComboBox.SelectedIndexChanged += OpenTicketsPriorityComboBox_SelectedIndexChanged;
            closedTicketsPriorityComboBox.SelectedIndexChanged += ClosedTicketsPriorityComboBox_SelectedIndexChanged;
            LoadTickets();
        }
        private void OpenTicketsPriorityComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyOpenFilters();
        }

        private void ClosedTicketsPriorityComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyClosedFilters();
        }
        private void LoadTickets()
        {
            var allTickets = GlobalConfig.Connection.Ticket_GetAll();
            // (re-populate navigation properties here if you used manual lookup)

            var open = allTickets.Where(t => !t.CompletionFlag).ToList();
            var closed = allTickets.Where(t => t.CompletionFlag).ToList();

            // Reset and rebind DataSource so the ListBox refreshes  
            openTicketsListBox.DataSource = null;
            openTicketsListBox.DataSource = open;
            closedTicketsListBox.DataSource = null;
            closedTicketsListBox.DataSource = closed;
        }

        private void openTicketsNewTicketButton_Click(object sender, EventArgs e)
        {
            Hide();
            var form = NewTicketForm.GetInstance(this);
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();
        }

        private void openTicketsEditSelectedButton_Click(object sender, EventArgs e)
        {
            if (openTicketsListBox.SelectedItem is TicketModel ticket)
            {
                Hide();
                var form = EditTicketForm.GetInstance(this, ticket);
                form.StartPosition = FormStartPosition.CenterScreen;
                form.Show();
            }
            else
            {
                MessageBox.Show("Please select an open ticket to edit.", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void closedTicketsEditSelectedButton_Click(object sender, EventArgs e)
        {
            if (closedTicketsListBox.SelectedItem is TicketModel ticket)
            {
                Hide();
                var form = EditTicketForm.GetInstance(this, ticket);
                form.StartPosition = FormStartPosition.CenterScreen;
                form.Show();
            }
            else
            {
                MessageBox.Show("Please select a closed ticket to edit.", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void closeTicketButton_Click(object sender, EventArgs e)
        {
            if (openTicketsListBox.SelectedItem is TicketModel ticket)
            {
                ticket.CompletionFlag = true;
                GlobalConfig.Connection.UpdateTicket(ticket); // or an Update method
                LoadTickets();
            }
            else
            {
                MessageBox.Show("Please select an open ticket to close.", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void reopenTicketButton_Click(object sender, EventArgs e)
        {
            if (closedTicketsListBox.SelectedItem is TicketModel ticket)
            {
                ticket.CompletionFlag = false;
                GlobalConfig.Connection.UpdateTicket(ticket); // or an Update method
                LoadTickets();
            }
            else
            {
                MessageBox.Show("Please select a closed ticket to reopen.", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void managePersonelButton_Click(object sender, EventArgs e)
        {
            Hide();
            var form = PersonelManagementForm.GetInstance(this);
            form.StartPosition = FormStartPosition.CenterScreen;
            form.Show();
        }
        public void ReloadOpenTickets()
        {
            LoadTickets();  // assuming you’ve refactored LoadTickets() as before
        }
        private void deleteSelectedOpenTicketButton_Click(object sender, EventArgs e)
        {
            // 1. Ensure something is selected
            if (!(openTicketsListBox.SelectedItem is TicketModel ticketToDelete))
            {
                MessageBox.Show("Please select an open ticket to delete.",
                                "No Selection",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            // 2. Confirm deletion
            var confirm = MessageBox.Show(
                $"Are you sure you want to delete ticket '{ticketToDelete.Name}'?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            // 3. Delete and reload
            GlobalConfig.Connection.DeleteTicket(ticketToDelete);
            LoadTickets();    // assuming you have this helper to rebind both lists
        }

        private void deleteSelectedClosedTicket_Click(object sender, EventArgs e)
        {
            // 1. Ensure something is selected
            if (!(closedTicketsListBox.SelectedItem is TicketModel ticketToDelete))
            {
                MessageBox.Show("Please select a closed ticket to delete.",
                                "No Selection",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            // 2. Confirm deletion
            var confirm = MessageBox.Show(
                $"Are you sure you want to delete ticket '{ticketToDelete.Name}'?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            // 3. Delete and reload
            GlobalConfig.Connection.DeleteTicket(ticketToDelete);
            LoadTickets();
        }
        private void openTicketsPriorityComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyOpenFilters();
        }

        private void closedTicketsPriorityComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ApplyClosedFilters();
        }
        private void ApplyOpenFilters()
        {
            var all = GlobalConfig.Connection.Ticket_GetAll()
                .Where(t => !t.CompletionFlag);

            if (openTicketsPriorityComboBox.SelectedItem is PriorityModel p)
                all = all.Where(t => t.PriorityId == p.Id);

            if (!string.IsNullOrWhiteSpace(openTicketsSearchTextBox.Text))
                all = all.Where(t => t.Name
                    .IndexOf(openTicketsSearchTextBox.Text, StringComparison.OrdinalIgnoreCase) >= 0);

            openTicketsListBox.DataSource = all.ToList();
        }

        private void ApplyClosedFilters()
        {
            var all = GlobalConfig.Connection.Ticket_GetAll()
                .Where(t => t.CompletionFlag);

            if (closedTicketsPriorityComboBox.SelectedItem is PriorityModel p)
                all = all.Where(t => t.PriorityId == p.Id);

            if (!string.IsNullOrWhiteSpace(closedTicketsSearchTextBox.Text))
                all = all.Where(t => t.Name
                    .IndexOf(closedTicketsSearchTextBox.Text, StringComparison.OrdinalIgnoreCase) >= 0);

            closedTicketsListBox.DataSource = all.ToList();
        }

        private void openTicketsSearchButton_Click(object sender, EventArgs e)
        {
            ApplyOpenFilters();
        }

        private void closedTicketsSearchButton_Click(object sender, EventArgs e)
        {
            ApplyClosedFilters();
        }
    }
}
