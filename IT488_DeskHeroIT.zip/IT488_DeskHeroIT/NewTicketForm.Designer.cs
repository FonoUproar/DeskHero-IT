﻿namespace IT488_DeskHeroIT
{
    partial class NewTicketForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.newTicketGroupBox = new System.Windows.Forms.GroupBox();
            this.ticketDifficultyComboBox = new System.Windows.Forms.ComboBox();
            this.ticketDifficultyLabel = new System.Windows.Forms.Label();
            this.ticketNameTextBox = new System.Windows.Forms.TextBox();
            this.ticketNameLabel = new System.Windows.Forms.Label();
            this.ticketPriorityComboBox = new System.Windows.Forms.ComboBox();
            this.ticketPriorityLabel = new System.Windows.Forms.Label();
            this.createTicketButton = new System.Windows.Forms.Button();
            this.clearTicketButton = new System.Windows.Forms.Button();
            this.issueDescriptionTextbox = new System.Windows.Forms.TextBox();
            this.ticketDesciptionLabel = new System.Windows.Forms.Label();
            this.estimatedCompletionTimeTextBox = new System.Windows.Forms.TextBox();
            this.estimatedCompletionTimeLabel = new System.Windows.Forms.Label();
            this.assignedTeamMemberComboBox = new System.Windows.Forms.ComboBox();
            this.assignedTeamMemberLabel = new System.Windows.Forms.Label();
            this.backButton = new System.Windows.Forms.Button();
            this.newTicketGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // newTicketGroupBox
            // 
            this.newTicketGroupBox.Controls.Add(this.ticketDifficultyComboBox);
            this.newTicketGroupBox.Controls.Add(this.ticketDifficultyLabel);
            this.newTicketGroupBox.Controls.Add(this.ticketNameTextBox);
            this.newTicketGroupBox.Controls.Add(this.ticketNameLabel);
            this.newTicketGroupBox.Controls.Add(this.ticketPriorityComboBox);
            this.newTicketGroupBox.Controls.Add(this.ticketPriorityLabel);
            this.newTicketGroupBox.Controls.Add(this.createTicketButton);
            this.newTicketGroupBox.Controls.Add(this.clearTicketButton);
            this.newTicketGroupBox.Controls.Add(this.issueDescriptionTextbox);
            this.newTicketGroupBox.Controls.Add(this.ticketDesciptionLabel);
            this.newTicketGroupBox.Controls.Add(this.estimatedCompletionTimeTextBox);
            this.newTicketGroupBox.Controls.Add(this.estimatedCompletionTimeLabel);
            this.newTicketGroupBox.Controls.Add(this.assignedTeamMemberComboBox);
            this.newTicketGroupBox.Controls.Add(this.assignedTeamMemberLabel);
            this.newTicketGroupBox.Location = new System.Drawing.Point(47, 8);
            this.newTicketGroupBox.Name = "newTicketGroupBox";
            this.newTicketGroupBox.Size = new System.Drawing.Size(287, 378);
            this.newTicketGroupBox.TabIndex = 3;
            this.newTicketGroupBox.TabStop = false;
            this.newTicketGroupBox.Text = "New Ticket";
            // 
            // ticketDifficultyComboBox
            // 
            this.ticketDifficultyComboBox.FormattingEnabled = true;
            this.ticketDifficultyComboBox.Items.AddRange(new object[] {
            "Close "});
            this.ticketDifficultyComboBox.Location = new System.Drawing.Point(89, 79);
            this.ticketDifficultyComboBox.Name = "ticketDifficultyComboBox";
            this.ticketDifficultyComboBox.Size = new System.Drawing.Size(184, 21);
            this.ticketDifficultyComboBox.TabIndex = 18;
            // 
            // ticketDifficultyLabel
            // 
            this.ticketDifficultyLabel.AutoSize = true;
            this.ticketDifficultyLabel.Location = new System.Drawing.Point(12, 82);
            this.ticketDifficultyLabel.Name = "ticketDifficultyLabel";
            this.ticketDifficultyLabel.Size = new System.Drawing.Size(80, 13);
            this.ticketDifficultyLabel.TabIndex = 17;
            this.ticketDifficultyLabel.Text = "Ticket Difficulty";
            // 
            // ticketNameTextBox
            // 
            this.ticketNameTextBox.Location = new System.Drawing.Point(89, 22);
            this.ticketNameTextBox.Name = "ticketNameTextBox";
            this.ticketNameTextBox.Size = new System.Drawing.Size(184, 20);
            this.ticketNameTextBox.TabIndex = 16;
            // 
            // ticketNameLabel
            // 
            this.ticketNameLabel.AutoSize = true;
            this.ticketNameLabel.Location = new System.Drawing.Point(12, 29);
            this.ticketNameLabel.Name = "ticketNameLabel";
            this.ticketNameLabel.Size = new System.Drawing.Size(68, 13);
            this.ticketNameLabel.TabIndex = 15;
            this.ticketNameLabel.Text = "Ticket Name";
            // 
            // ticketPriorityComboBox
            // 
            this.ticketPriorityComboBox.FormattingEnabled = true;
            this.ticketPriorityComboBox.Items.AddRange(new object[] {
            "Close "});
            this.ticketPriorityComboBox.Location = new System.Drawing.Point(89, 51);
            this.ticketPriorityComboBox.Name = "ticketPriorityComboBox";
            this.ticketPriorityComboBox.Size = new System.Drawing.Size(184, 21);
            this.ticketPriorityComboBox.TabIndex = 14;
            // 
            // ticketPriorityLabel
            // 
            this.ticketPriorityLabel.AutoSize = true;
            this.ticketPriorityLabel.Location = new System.Drawing.Point(12, 54);
            this.ticketPriorityLabel.Name = "ticketPriorityLabel";
            this.ticketPriorityLabel.Size = new System.Drawing.Size(71, 13);
            this.ticketPriorityLabel.TabIndex = 13;
            this.ticketPriorityLabel.Text = "Ticket Priority";
            // 
            // createTicketButton
            // 
            this.createTicketButton.Location = new System.Drawing.Point(217, 337);
            this.createTicketButton.Name = "createTicketButton";
            this.createTicketButton.Size = new System.Drawing.Size(56, 23);
            this.createTicketButton.TabIndex = 10;
            this.createTicketButton.Text = "Create";
            this.createTicketButton.UseVisualStyleBackColor = true;
            this.createTicketButton.Click += new System.EventHandler(this.createTicketButton_Click);
            // 
            // clearTicketButton
            // 
            this.clearTicketButton.Location = new System.Drawing.Point(10, 337);
            this.clearTicketButton.Name = "clearTicketButton";
            this.clearTicketButton.Size = new System.Drawing.Size(53, 23);
            this.clearTicketButton.TabIndex = 9;
            this.clearTicketButton.Text = "Clear";
            this.clearTicketButton.UseVisualStyleBackColor = true;
            this.clearTicketButton.Click += new System.EventHandler(this.clearTicketButton_Click);
            // 
            // issueDescriptionTextbox
            // 
            this.issueDescriptionTextbox.Location = new System.Drawing.Point(10, 179);
            this.issueDescriptionTextbox.Multiline = true;
            this.issueDescriptionTextbox.Name = "issueDescriptionTextbox";
            this.issueDescriptionTextbox.Size = new System.Drawing.Size(263, 152);
            this.issueDescriptionTextbox.TabIndex = 8;
            // 
            // ticketDesciptionLabel
            // 
            this.ticketDesciptionLabel.AutoSize = true;
            this.ticketDesciptionLabel.Location = new System.Drawing.Point(12, 163);
            this.ticketDesciptionLabel.Name = "ticketDesciptionLabel";
            this.ticketDesciptionLabel.Size = new System.Drawing.Size(91, 13);
            this.ticketDesciptionLabel.TabIndex = 7;
            this.ticketDesciptionLabel.Text = "Issue Description:";
            // 
            // estimatedCompletionTimeTextBox
            // 
            this.estimatedCompletionTimeTextBox.Location = new System.Drawing.Point(153, 136);
            this.estimatedCompletionTimeTextBox.Name = "estimatedCompletionTimeTextBox";
            this.estimatedCompletionTimeTextBox.Size = new System.Drawing.Size(120, 20);
            this.estimatedCompletionTimeTextBox.TabIndex = 6;
            // 
            // estimatedCompletionTimeLabel
            // 
            this.estimatedCompletionTimeLabel.AutoSize = true;
            this.estimatedCompletionTimeLabel.Location = new System.Drawing.Point(12, 143);
            this.estimatedCompletionTimeLabel.Name = "estimatedCompletionTimeLabel";
            this.estimatedCompletionTimeLabel.Size = new System.Drawing.Size(136, 13);
            this.estimatedCompletionTimeLabel.TabIndex = 5;
            this.estimatedCompletionTimeLabel.Text = "Estimated time to complete ";
            // 
            // assignedTeamMemberComboBox
            // 
            this.assignedTeamMemberComboBox.FormattingEnabled = true;
            this.assignedTeamMemberComboBox.Items.AddRange(new object[] {
            "Royce",
            "Brendan",
            "Wes",
            "Uziel",
            "Zaid"});
            this.assignedTeamMemberComboBox.Location = new System.Drawing.Point(89, 110);
            this.assignedTeamMemberComboBox.Name = "assignedTeamMemberComboBox";
            this.assignedTeamMemberComboBox.Size = new System.Drawing.Size(184, 21);
            this.assignedTeamMemberComboBox.TabIndex = 4;
            // 
            // assignedTeamMemberLabel
            // 
            this.assignedTeamMemberLabel.AutoSize = true;
            this.assignedTeamMemberLabel.Location = new System.Drawing.Point(12, 113);
            this.assignedTeamMemberLabel.Name = "assignedTeamMemberLabel";
            this.assignedTeamMemberLabel.Size = new System.Drawing.Size(62, 13);
            this.assignedTeamMemberLabel.TabIndex = 3;
            this.assignedTeamMemberLabel.Text = "Assigned to";
            // 
            // backButton
            // 
            this.backButton.Location = new System.Drawing.Point(9, 8);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(32, 34);
            this.backButton.TabIndex = 12;
            this.backButton.Text = "<";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // NewTicketForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(352, 388);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.newTicketGroupBox);
            this.Name = "NewTicketForm";
            this.Text = "NewTicketForm";
            this.newTicketGroupBox.ResumeLayout(false);
            this.newTicketGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox newTicketGroupBox;
        private System.Windows.Forms.TextBox ticketNameTextBox;
        private System.Windows.Forms.Label ticketNameLabel;
        private System.Windows.Forms.ComboBox ticketPriorityComboBox;
        private System.Windows.Forms.Label ticketPriorityLabel;
        private System.Windows.Forms.Button createTicketButton;
        private System.Windows.Forms.Button clearTicketButton;
        private System.Windows.Forms.TextBox issueDescriptionTextbox;
        private System.Windows.Forms.Label ticketDesciptionLabel;
        private System.Windows.Forms.TextBox estimatedCompletionTimeTextBox;
        private System.Windows.Forms.Label estimatedCompletionTimeLabel;
        private System.Windows.Forms.ComboBox assignedTeamMemberComboBox;
        private System.Windows.Forms.Label assignedTeamMemberLabel;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.ComboBox ticketDifficultyComboBox;
        private System.Windows.Forms.Label ticketDifficultyLabel;
    }
}