﻿using System.Windows.Forms;

namespace IT488_DeskHeroIT
{
    internal class DeskHeroIT : Form
    {
    }
}