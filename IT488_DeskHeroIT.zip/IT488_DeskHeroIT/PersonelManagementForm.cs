﻿using DeskHeroLibrary.Models;
using DeskHeroLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//namespace IT488_DeskHeroIT
//{
//    public partial class PersonelManagementForm: Form
//    {
//        private static PersonelManagementForm instance;
//        private Form dashboardForm;
  

//        public PersonelManagementForm(Form DashboardForm)
//        {
//            InitializeComponent();
//            dashboardForm = DashboardForm;
//        }
//        public static PersonelManagementForm GetInstance(Form home)
//        {
//            if (instance == null || instance.IsDisposed)
//            {
//                instance = new PersonelManagementForm(home);
//            }
//            return instance;
//        }

//        private void backButton_Click(object sender, EventArgs e)
//        {
//            this.Hide();
//            if (dashboardForm != null && !dashboardForm.IsDisposed)
//            {
//                dashboardForm.StartPosition = FormStartPosition.CenterScreen;
//                dashboardForm.Show();
//            }
//            else
//            {
//                dashboardForm = new DashboardForm();
//                dashboardForm.StartPosition = FormStartPosition.CenterScreen;
//                dashboardForm.Show();
//            }
//        }

//        private void createTeamMemberButton_Click(object sender, EventArgs e)
//        {
//            if (ValidateTeamMember())
//            {
                
//            }

//        }
//        private bool ValidateTeamMember()
//        {
//            bool output = true;
//            if (teamMemberNameTextBox.Text == null)
//            {
//                MessageBox.Show("Name field is blank, please enter a valid name");
//                output = false;
//            }

//            if (teamMemberNameTextBox.Text.Length > 100)
//            {
//                MessageBox.Show("Name exceeds 100 characters, please enter a shorter name");
//                output = false;
//            }
//            if (teamMemberProficiencyComboBox.Text == null)
//            {
//                MessageBox.Show("Team member proficiency is not selected, please select a valid option");
//            }
//            return output;
//        }

//        private void clearEntryButton_Click(object sender, EventArgs e)
//        {

//        }

//        private void deleteSelectedButton_Click(object sender, EventArgs e)
//        {

//        }
//    }
//}
namespace IT488_DeskHeroIT
{
    public partial class PersonelManagementForm : Form
    {
        private static PersonelManagementForm instance;
        private readonly Form dashboardForm;

        public PersonelManagementForm(Form DashboardForm)
        {
            InitializeComponent();
            dashboardForm = DashboardForm;
            GlobalConfig.InitializeConnections();

            // Bind proficiencies dropdown
            teamMemberProficiencyComboBox.DataSource = GlobalConfig.Connection.Proficiency_GetAll();
            teamMemberProficiencyComboBox.DisplayMember = "Name";
            teamMemberProficiencyComboBox.ValueMember = "Id";

            // Initial load of team members
            LoadTeamMembers();
        }

        public static PersonelManagementForm GetInstance(Form home)
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new PersonelManagementForm(home);
            }
            return instance;
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            if (dashboardForm != null && !dashboardForm.IsDisposed)
            {
                dashboardForm.StartPosition = FormStartPosition.CenterScreen;
                dashboardForm.Show();
            }
            else
            {
                var newDash = new DashboardForm();
                newDash.StartPosition = FormStartPosition.CenterScreen;
                newDash.Show();
            }
        }

        private void createTeamMemberButton_Click(object sender, EventArgs e)
        {
            if (!ValidateTeamMember()) return;

            var model = new TeamMemberModel
            {
                Name = teamMemberNameTextBox.Text.Trim(),
                ProficiencyId = (int)teamMemberProficiencyComboBox.SelectedValue
            };

            GlobalConfig.Connection.CreateTeamMember(model);

            ClearEntryFields();
            LoadTeamMembers();
        }

        private bool ValidateTeamMember()
        {
            if (string.IsNullOrWhiteSpace(teamMemberNameTextBox.Text))
            {
                MessageBox.Show("Name field is blank, please enter a valid name");
                return false;
            }
            if (teamMemberNameTextBox.Text.Length > 100)
            {
                MessageBox.Show("Name exceeds 100 characters, please enter a shorter name");
                return false;
            }
            if (teamMemberProficiencyComboBox.SelectedItem == null)
            {
                MessageBox.Show("Team member proficiency is not selected, please select a valid option");
                return false;
            }
            return true;
        }

        private void clearEntryButton_Click(object sender, EventArgs e)
        {
            ClearEntryFields();
        }

        private void deleteSelectedButton_Click(object sender, EventArgs e)
        {
            var selected = (TeamMemberModel)currentTeamMembersListBox.SelectedItem;
            if (selected == null)
            {
                MessageBox.Show("Please select a team member to delete.");
                return;
            }

            var confirm = MessageBox.Show(
                $"Are you sure you want to delete '{selected.Name}'?",
                "Confirm Delete",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Warning);

            if (confirm == DialogResult.Yes)
            {
                GlobalConfig.Connection.DeleteTeamMember(selected);
                LoadTeamMembers();
            }
        }

        private void LoadTeamMembers()
        {
            List<TeamMemberModel> members = GlobalConfig.Connection.TeamMember_GetAll();
            currentTeamMembersListBox.DataSource = members;
            // Use ToString() override on TeamMemberModel to display both Name and Proficiency if desired
            currentTeamMembersListBox.DisplayMember = "Name";
            // or leave DisplayMember unset if overridden ToString() is more descriptive
        }

        private void ClearEntryFields()
        {
            teamMemberNameTextBox.Clear();
            teamMemberProficiencyComboBox.SelectedIndex = -1;
        }
    }
}