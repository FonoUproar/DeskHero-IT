﻿using DeskHeroLibrary;
using DeskHeroLibrary.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT488_DeskHeroIT
{
    public partial class EditTicketForm : Form
    {
        private static EditTicketForm instance;
        private readonly DashboardForm dashboardForm;
        private readonly TicketModel ticketToEdit;

        // Original constructor (for blank/new)
        private EditTicketForm(DashboardForm parent)
        {
            InitializeComponent();
            dashboardForm = parent;
            InitializeLookups();
            ticketDifficultyComboBox.SelectionChangeCommitted += TicketDifficultyComboBox_SelectionChangeCommitted; 
        }
        private void TicketDifficultyComboBox_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (ticketDifficultyComboBox.SelectedValue is int profId && profId > 0)
            {
                var allMembers = GlobalConfig.Connection.TeamMember_GetAll();

                // Adjust the comparison based on your proficiency ID logic
                var eligible = allMembers.Where(tm => tm.ProficiencyId >= profId).ToList();

                assignedTeamMemberComboBox.DataSource = null;
                assignedTeamMemberComboBox.DataSource = eligible;
                assignedTeamMemberComboBox.DisplayMember = "Name";
                assignedTeamMemberComboBox.ValueMember = "Id";
            }
            else
            {
                assignedTeamMemberComboBox.DataSource = null;
            }
        }

        // New constructor overload to edit an existing ticket
        private EditTicketForm(DashboardForm parent, TicketModel ticket) : this(parent)
        {
            ticketToEdit = ticket ?? throw new ArgumentNullException(nameof(ticket));
            PopulateFormFields();
        }

        // Existing GetInstance
        public static EditTicketForm GetInstance(DashboardForm home)
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new EditTicketForm(home);
            }
            return instance;
        }

        // New overload
        public static EditTicketForm GetInstance(DashboardForm home, TicketModel ticket)
        {
            if (instance == null || instance.IsDisposed)
            {
                instance = new EditTicketForm(home, ticket);
            }
            return instance;
        }

        private void EditTicketForm_Load(object sender, EventArgs e)
        {
            // If ticketToEdit is null, we're in "new" mode—otherwise fields already populated
            if (ticketToEdit == null)
            {
                // Optionally clear fields for a fresh entry
                ClearFormFields();
            }
        }

        private void InitializeLookups()
        {
            // Priority
            ticketPriorityComboBox.DataSource = GlobalConfig.Connection.Priority_GetAll();
            ticketPriorityComboBox.DisplayMember = "Name";
            ticketPriorityComboBox.ValueMember = "Id";

            // Proficiency
            ticketDifficultyComboBox.DataSource = GlobalConfig.Connection.Proficiency_GetAll();
            ticketDifficultyComboBox.DisplayMember = "Name";
            ticketDifficultyComboBox.ValueMember = "Id";

            // Team Member
            assignedTeamMemberComboBox.DataSource = GlobalConfig.Connection.TeamMember_GetAll();
            assignedTeamMemberComboBox.DisplayMember = "Name";
            assignedTeamMemberComboBox.ValueMember = "Id";
        }

        private void PopulateFormFields()
        {
            // Fill controls from ticketToEdit
            ticketNameTextBox.Text = ticketToEdit.Name;
            ticketPriorityComboBox.SelectedValue = ticketToEdit.PriorityId;
            ticketDifficultyComboBox.SelectedValue = ticketToEdit.ProficiencyId;
            assignedTeamMemberComboBox.SelectedValue = ticketToEdit.TeamMemberAssignedId;
            estimatedCompletionTimeTextBox.Text = ticketToEdit.EstimatedTimeToComplete.ToString();
            descriptionTextBox.Text = ticketToEdit.Description;
            completionCheckBox.Checked = ticketToEdit.CompletionFlag;
        }

        private void ClearFormFields()
        {
            ticketNameTextBox.Clear();
            ticketPriorityComboBox.SelectedIndex = -1;
            ticketDifficultyComboBox.SelectedIndex = -1;
            assignedTeamMemberComboBox.SelectedIndex = -1;
            estimatedCompletionTimeTextBox.Clear();
            descriptionTextBox.Clear();
            completionCheckBox.Checked = false;
        }

        private void backButton_Click(object sender, EventArgs e)
        {
            Hide();
            if (dashboardForm != null && !dashboardForm.IsDisposed)
                dashboardForm.Show();
            else
                new DashboardForm().Show();
        }

        private void clearTicketButton_Click(object sender, EventArgs e)
        {
            ClearFormFields();
        }

        private void confirmChangesButton_Click(object sender, EventArgs e)
        {
            // Validate
            if (string.IsNullOrWhiteSpace(ticketNameTextBox.Text))
            {
                MessageBox.Show("Ticket name is required.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (!int.TryParse(estimatedCompletionTimeTextBox.Text, out int hours))
            {
                MessageBox.Show("Estimated time must be a number.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (ticketPriorityComboBox.SelectedValue == null ||
                ticketDifficultyComboBox.SelectedValue == null ||
                assignedTeamMemberComboBox.SelectedValue == null)
            {
                MessageBox.Show("Please select Priority, Difficulty, and Assigned Team Member.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Either update existing or create new
            var model = ticketToEdit ?? new TicketModel();

            model.Name = ticketNameTextBox.Text.Trim();
            model.PriorityId = (int)ticketPriorityComboBox.SelectedValue;
            model.ProficiencyId = (int)ticketDifficultyComboBox.SelectedValue;
            model.TeamMemberAssignedId = (int)assignedTeamMemberComboBox.SelectedValue;
            model.EstimatedTimeToComplete = hours;
            model.Description = descriptionTextBox.Text.Trim();
            model.CompletionFlag = completionCheckBox.Checked;

            // Call data layer
            if (ticketToEdit != null)
                GlobalConfig.Connection.UpdateTicket(model);  // you’ll need an UpdateTicket SP/method
            else
                GlobalConfig.Connection.CreateTicket(model);

            MessageBox.Show("Ticket saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Return to dashboard and refresh
            Hide();
            if (dashboardForm is DashboardForm dash)
            {
                dash.ReloadOpenTickets();
                dash.Show();
            } // or cast to DashboardForm and call its LoadTickets
        }
        private void EditTicketForm_FormClosed(object sender, FormClosedEventArgs e)
        => instance = null;
    }
}
//namespace IT488_DeskHeroIT
//{
//    public partial class EditTicketForm: Form
//    {
//        private static EditTicketForm instance;
//        private Form dashboardForm;
//        public EditTicketForm(Form DashboardForm)
//        {
//            InitializeComponent();
//            dashboardForm = DashboardForm;
//            ticketPriorityComboBox.DataSource = GlobalConfig.Connection.Priority_GetAll();
//            ticketPriorityComboBox.DisplayMember = "Name";
//            ticketPriorityComboBox.ValueMember = "Id";
//        }
//        public static EditTicketForm GetInstance(Form home)
//        {
//            if (instance == null || instance.IsDisposed)
//            {
//                instance = new EditTicketForm(home);
//            }
//            return instance;
//        }

//        private void backButton_Click(object sender, EventArgs e)
//        {
//            this.Hide();
//            if (dashboardForm != null && !dashboardForm.IsDisposed)
//            {
//                dashboardForm.StartPosition = FormStartPosition.CenterScreen;
//                dashboardForm.Show();
//            }
//            else
//            {
//                dashboardForm = new DashboardForm();
//                dashboardForm.StartPosition = FormStartPosition.CenterScreen;
//                dashboardForm.Show();
//            }
//        }

//        private void confirmChangesButton_Click(object sender, EventArgs e)
//        {

//        }

//        private void clearTicketButton_Click(object sender, EventArgs e)
//        {

//        }
//    }
//}
